document.addEventListener('DOMContentLoaded', function(){
	setTimeout(function(){
		let layout = document.querySelector(".layout")
		layout.className += " js-loaded"

	}, 500)
})
