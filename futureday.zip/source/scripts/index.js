#= require ../../bower_components/jquery/dist/jquery.min.js
#= require ../../bower_components/jquery.scrollend/src/jquery.scrollend.js
#= require ../../bower_components/jquery-validation/dist/jquery.validate.min.js
#= require ../../bower_components/jquery-validation/src/localization/messages_ru.js
#= require ../../bower_components/jquery-form/jquery.form.js
#= require ../../bower_components/jquery-mask-plugin/src/jquery.mask.js
#= require ./blocks/**/*.js
